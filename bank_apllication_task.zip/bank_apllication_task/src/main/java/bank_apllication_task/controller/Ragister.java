package bank_apllication_task.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bank_apllication_task.dao.UserDao;
import bank_apllication_task.dto.BankUser;

@WebServlet("/ragister")
public class Ragister extends HttpServlet{
	
	BankUser user=new BankUser();
	
	UserDao dao=new UserDao();
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//
		//int id = Integer.parseInt(req.getParameter("id"));
		String bankname = req.getParameter("Bankname");
		String username = req.getParameter("username");
		int accountno = Integer.parseInt(req.getParameter("accountno"));
		String address = req.getParameter("address");
		double initialbal=Double.parseDouble(req.getParameter("initialbal"));
		double balance=Double.parseDouble(req.getParameter("balance"));
		
		user.setBankname(bankname);
		user.setUsername(username);
		user.setAccountno(accountno);
		user.setAddress(address);
		user.setInitialbal(initialbal);
		user.setBalance(balance);
		
		BankUser count;

		try {
			count = dao.ragisterUser(user);
			if (count != null) {
				
				req.setAttribute("message", "Signup Successfull!!! Please LogIn");
				
				RequestDispatcher dispatcher=req.getRequestDispatcher("login.jsp");
				dispatcher.forward(req, resp);
			} else {
				resp.getWriter().print("Signup Unsuccessful");
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

		
	
	
	
	

}
