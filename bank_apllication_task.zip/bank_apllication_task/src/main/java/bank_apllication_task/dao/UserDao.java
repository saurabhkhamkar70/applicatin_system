package bank_apllication_task.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import bank_apllication_task.dto.BankUser;

public class UserDao {
	
	public EntityManager getEntityManager() {
		return Persistence.createEntityManagerFactory("bank_application_task").createEntityManager();
	}
	
	public BankUser ragisterUser(BankUser user) {
		
		EntityManager manager=getEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		try {

			transaction.begin();
			manager.persist(user);
			transaction.commit();
			
		} catch (Exception e) {
		
		}
		return user;
		
	}

}
